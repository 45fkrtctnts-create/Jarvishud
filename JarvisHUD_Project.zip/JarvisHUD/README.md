# JARVIS HUD — Android MVP

Bu proje, konuşma sesine tepki veren **yüzen JARVIS HUD** ve ana ekrana eklenebilen **dikdörtgen Android widget** için hazırlanmış ilk çalışan sürüm taslağıdır.

## İçerik

- Yüzen overlay panel
- Sürükleyerek taşıma
- Mikrofon ses seviyesine göre pulse yapan JARVIS çekirdeği
- Saat ve tarih
- Google News Türkçe RSS üzerinden 3 son dakika başlığı
- Android Takvim'den bugünkü etkinlikler
- Ana ekran widget'ı: saat + tarih + JARVIS + haber + takvim + günlük program
- Widget'a dokununca kontrol uygulamasını açma

## APK'ya dönüştürme — Android Studio olmadan

Projeyi GitHub'a yükleyip **Actions → Build Android APK → Run workflow** çalıştırabilirsin. Oluşan `JarvisHUD-debug-apk` artifact'ının içinde `app-debug.apk` bulunur.

## Android Studio ile

Projeyi aç → Gradle sync → Run veya `assembleDebug`.

## İzinler

- `RECORD_AUDIO`: JARVIS halkasının sese tepki vermesi
- `READ_CALENDAR`: günlük program
- `SYSTEM_ALERT_WINDOW`: diğer uygulamaların üzerinde yüzen HUD
- `INTERNET`: haber RSS'i
- Bildirim/foreground service izinleri: yüzen HUD servisinin Android kurallarına uygun çalışması

## Not

Ana ekran widget'ları Android kısıtları nedeniyle gerçek zamanlı 60 FPS animasyon için uygun değildir. Bu nedenle widget statik/periodik güncellenir; gerçek zamanlı animasyon **Floating HUD** içinde çalışır.
