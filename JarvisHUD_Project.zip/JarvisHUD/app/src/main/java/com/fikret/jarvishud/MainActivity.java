package com.fikret.jarvishud;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.widget.Button;
import android.widget.TextView;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 10;
    private static final int REQUEST_AUDIO_PERMISSION = 11;
    private static final String UTTERANCE_ID = "jarvis-response";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private JarvisCoreView core;
    private TextView statusText;
    private TextView commandText;
    private boolean ttsReady;
    private boolean ttsInitializationComplete;
    private boolean pendingPermissionStart;
    private String pendingSpeech;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        core = findViewById(R.id.corePreview);
        core.setAmplitude(0.18f);
        statusText = findViewById(R.id.txtAssistantStatus);
        commandText = findViewById(R.id.txtAssistantCommand);
        core.setOnClickListener(v -> toggleListening());
        findViewById(R.id.btnVoice).setOnClickListener(v -> toggleListening());

        initializeSpeechRecognizer();
        initializeTextToSpeech();
        requestRuntimePermissions();

        Button start=findViewById(R.id.btnStartOverlay), stop=findViewById(R.id.btnStopOverlay), refresh=findViewById(R.id.btnRefreshWidget);
        start.setOnClickListener(v -> {
            if(!Settings.canDrawOverlays(this)) {
                Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
                startActivity(i); return;
            }
            Intent i=new Intent(this,FloatingHudService.class);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
        });
        stop.setOnClickListener(v -> stopService(new Intent(this,FloatingHudService.class)));
        refresh.setOnClickListener(v -> { NewsFetcher.fetch(this, x -> JarvisWidgetProvider.updateAll(this)); JarvisWidgetProvider.updateAll(this); });
    }

    private void initializeSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            showError("Bu cihazda konuşma tanıma kullanılamıyor.");
            return;
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                setAssistantState(JarvisCoreView.Mode.LISTENING, "Sizi dinliyorum...");
            }

            @Override public void onBeginningOfSpeech() {
                setAssistantState(JarvisCoreView.Mode.LISTENING, "Konuşmanızı dinliyorum...");
            }

            @Override public void onRmsChanged(float rmsdB) {
                float level = Math.max(0f, Math.min(0.35f, (rmsdB + 2f) / 14f * 0.35f));
                if (core != null) core.setAmplitude(level);
            }

            @Override public void onPartialResults(Bundle partialResults) {
                showRecognitionText(bestResult(partialResults));
            }

            @Override public void onResults(Bundle results) {
                String command = bestResult(results);
                if (command.isEmpty()) {
                    handleRecognitionError(SpeechRecognizer.ERROR_NO_MATCH);
                    return;
                }
                showRecognitionText(command);
                sendToJarvis(command);
            }

            @Override public void onEndOfSpeech() {
                setAssistantState(JarvisCoreView.Mode.PROCESSING, "Komutunuz işleniyor...");
            }

            @Override public void onError(int error) {
                handleRecognitionError(error);
            }

            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEvent(int eventType, Bundle params) { }
        });
    }

    private void initializeTextToSpeech() {
        textToSpeech = new TextToSpeech(this, status -> {
            ttsInitializationComplete = true;
            if (status != TextToSpeech.SUCCESS || textToSpeech == null) {
                failPendingSpeech("Türkçe sesli yanıt başlatılamadı.");
                return;
            }
            int languageStatus = textToSpeech.setLanguage(new Locale("tr", "TR"));
            ttsReady = languageStatus != TextToSpeech.LANG_MISSING_DATA
                    && languageStatus != TextToSpeech.LANG_NOT_SUPPORTED;
            if (!ttsReady) {
                failPendingSpeech("Türkçe ses verisi kullanılamıyor.");
                return;
            }

            textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) {
                    runOnUiThread(() -> setAssistantState(JarvisCoreView.Mode.SPEAKING, "JARVIS yanıtlıyor..."));
                }

                @Override public void onDone(String utteranceId) {
                    runOnUiThread(() -> setAssistantState(JarvisCoreView.Mode.IDLE, "Hazır"));
                }

                @Override public void onError(String utteranceId) {
                    runOnUiThread(() -> showError("Yanıt seslendirilemedi."));
                }
            });

            if (pendingSpeech != null) {
                String text = pendingSpeech;
                pendingSpeech = null;
                speak(text);
            }
        });
    }

    private void toggleListening() {
        if (core != null && core.getMode() == JarvisCoreView.Mode.LISTENING) {
            stopListening();
            return;
        }
        if (core != null && core.getMode() == JarvisCoreView.Mode.SPEAKING && textToSpeech != null) {
            textToSpeech.stop();
        }
        startListening();
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingPermissionStart = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO_PERMISSION);
            return;
        }
        if (speechRecognizer == null) {
            initializeSpeechRecognizer();
            if (speechRecognizer == null) return;
        }

        if (textToSpeech != null) textToSpeech.stop();
        showRecognitionText("Dinleme başlatılıyor...");
        setAssistantState(JarvisCoreView.Mode.LISTENING, "Dinlemeye hazırlanıyor...");
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        try {
            speechRecognizer.startListening(intent);
        } catch (RuntimeException exception) {
            showError("Dinleme başlatılamadı.");
        }
    }

    private void stopListening() {
        if (speechRecognizer == null) return;
        try {
            speechRecognizer.stopListening();
            setAssistantState(JarvisCoreView.Mode.PROCESSING, "Komutunuz işleniyor...");
        } catch (RuntimeException exception) {
            handleRecognitionError(SpeechRecognizer.ERROR_CLIENT);
        }
    }

    private void sendToJarvis(String command) {
        setAssistantState(JarvisCoreView.Mode.PROCESSING, "Yanıt hazırlanıyor...");
        String response = command.toLowerCase(new Locale("tr", "TR")).contains("merhaba")
                ? "Merhaba. Sizi dinliyorum."
                : "Komutunuzu aldım.";
        speak(response);
    }

    private void speak(String text) {
        if (textToSpeech == null || !ttsReady) {
            if (ttsInitializationComplete) {
                showError("Türkçe sesli yanıt kullanılamıyor.");
            } else {
                pendingSpeech = text;
            }
            return;
        }
        int result = textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID);
        if (result == TextToSpeech.ERROR) showError("Yanıt seslendirilemedi.");
    }

    private void failPendingSpeech(String message) {
        pendingSpeech = null;
        showError(message);
    }

    private String bestResult(Bundle bundle) {
        if (bundle == null) return "";
        ArrayList<String> results = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return results != null && !results.isEmpty() && results.get(0) != null
                ? results.get(0).trim()
                : "";
    }

    private void showRecognitionText(String text) {
        if (commandText != null && !text.isEmpty()) commandText.setText(text);
    }

    private void setAssistantState(JarvisCoreView.Mode mode, String message) {
        if (core != null) core.setMode(mode);
        if (statusText != null) statusText.setText(mode.name() + " • " + message);
    }

    private void handleRecognitionError(int error) {
        String message;
        switch (error) {
            case SpeechRecognizer.ERROR_NO_MATCH:
                message = "Konuşma anlaşılamadı.";
                break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                message = "Konuşma algılanmadı.";
                break;
            case SpeechRecognizer.ERROR_AUDIO:
                message = "Mikrofon sesine erişilemedi.";
                break;
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                message = "Konuşma tanıma ağına ulaşılamadı.";
                break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                message = "Mikrofon izni gerekli.";
                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                message = "Konuşma tanıma meşgul. Tekrar deneyin.";
                break;
            default:
                message = "Konuşma tanıma başarısız oldu.";
                break;
        }
        showError(message);
    }

    private void showError(String message) {
        setAssistantState(JarvisCoreView.Mode.ERROR, message);
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(() -> setAssistantState(JarvisCoreView.Mode.IDLE, "Hazır"), 2200);
    }

    private void requestRuntimePermissions(){
        if(Build.VERSION.SDK_INT<23)return;
        List<String> req=new ArrayList<>();
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.RECORD_AUDIO);
        if(checkSelfPermission(Manifest.permission.READ_CALENDAR)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.READ_CALENDAR);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.POST_NOTIFICATIONS);
        if(!req.isEmpty())requestPermissions(req.toArray(new String[0]),REQUEST_PERMISSIONS);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO_PERMISSION) {
            pendingPermissionStart = false;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startListening();
            } else {
                showError("Mikrofon izni verilmedi.");
            }
            return;
        }

        if (requestCode == REQUEST_PERMISSIONS) {
            for (int i = 0; i < permissions.length && i < grantResults.length; i++) {
                if (Manifest.permission.RECORD_AUDIO.equals(permissions[i])
                        && grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    showError("Mikrofon izni verilmedi.");
                    break;
                }
            }
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (speechRecognizer != null) {
            try { speechRecognizer.cancel(); } catch (RuntimeException ignored) { }
            speechRecognizer.destroy();
            speechRecognizer = null;
        }
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
            textToSpeech = null;
        }
        super.onDestroy();
    }
}
