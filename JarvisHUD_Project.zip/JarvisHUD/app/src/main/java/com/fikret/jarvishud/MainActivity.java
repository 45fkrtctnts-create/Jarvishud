package com.fikret.jarvishud;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        JarvisCoreView preview=findViewById(R.id.corePreview); preview.setAmplitude(0.18f);
        requestRuntimePermissions();

        Button start=findViewById(R.id.btnStartOverlay), stop=findViewById(R.id.btnStopOverlay), refresh=findViewById(R.id.btnRefreshWidget);
        start.setOnClickListener(v -> {
            if(!Settings.canDrawOverlays(this)) {
                Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
                startActivity(i); return;
            }
            Intent i=new Intent(this,FloatingHudService.class);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
        });
        stop.setOnClickListener(v -> stopService(new Intent(this,FloatingHudService.class)));
        refresh.setOnClickListener(v -> { NewsFetcher.fetch(this, x -> JarvisWidgetProvider.updateAll(this)); JarvisWidgetProvider.updateAll(this); });
    }

    private void requestRuntimePermissions(){
        if(Build.VERSION.SDK_INT<23)return;
        List<String> req=new ArrayList<>();
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.RECORD_AUDIO);
        if(checkSelfPermission(Manifest.permission.READ_CALENDAR)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.READ_CALENDAR);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.POST_NOTIFICATIONS);
        if(!req.isEmpty())requestPermissions(req.toArray(new String[0]),10);
    }
}
