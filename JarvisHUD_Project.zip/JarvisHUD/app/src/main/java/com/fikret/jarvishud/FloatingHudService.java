package com.fikret.jarvishud;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class FloatingHudService extends Service {
    private static final String CH = "jarvis_hud";
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private View root;
    private WindowManager.LayoutParams lp;
    private volatile boolean listening;
    private volatile boolean overlayActive;
    private AudioRecord recorder;
    private Thread micThread;
    private JarvisCoreView core;
    private Runnable clockTick;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(11, notification());
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        showOverlay();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public IBinder onBind(Intent intent) { return null; }

    private void showOverlay() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        root = LayoutInflater.from(this).inflate(R.layout.overlay_hud,null,false);
        core = root.findViewById(R.id.jarvisCore);
        if (core == null) {
            root = null;
            throw new IllegalStateException("overlay_hud must contain R.id.jarvisCore");
        }
        lp = new WindowManager.LayoutParams(dp(390), dp(240),
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START; lp.x = 24; lp.y = 120;
        wm.addView(root,lp);
        overlayActive = true;
        bindUi();
        startMic();
    }

    private void bindUi() {
        TextView time=root.findViewById(R.id.txtTime), date=root.findViewById(R.id.txtDate), cal=root.findViewById(R.id.txtCalendar), sched=root.findViewById(R.id.txtSchedule);
        clockTick = new Runnable(){ public void run(){
            if (!overlayActive || root == null) return;
            Calendar now=Calendar.getInstance();
            time.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(now.getTime()));
            date.setText(new SimpleDateFormat("dd MMMM yyyy",new Locale("tr","TR")).format(now.getTime()));
            cal.setText(new SimpleDateFormat("MMMM yyyy",new Locale("tr","TR")).format(now.getTime())+"\nPzt  Sal  Çar  Per  Cum  Cmt  Paz\nBugün: "+now.get(Calendar.DAY_OF_MONTH));
            mainHandler.postDelayed(this,15000);
        }};
        mainHandler.post(clockTick);
        List<String> agenda=ScheduleReader.today(this); StringBuilder sb=new StringBuilder(); for(String s:agenda) sb.append("• ").append(s).append('\n'); sched.setText(sb.toString().trim());
        fillNews(NewsFetcher.cached(this));
        NewsFetcher.fetch(this,titles -> mainHandler.post(() -> {
            if (overlayActive && root != null) fillNews(titles);
        }));
        root.findViewById(R.id.btnClose).setOnClickListener(v -> stopSelf());
        View drag=root.findViewById(R.id.dragBar); final int[] start={0,0}; final float[] touch={0,0};
        drag.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){ start[0]=lp.x; start[1]=lp.y; touch[0]=e.getRawX(); touch[1]=e.getRawY(); return true; }
            if(e.getAction()==MotionEvent.ACTION_MOVE){ lp.x=start[0]+(int)(e.getRawX()-touch[0]); lp.y=start[1]+(int)(e.getRawY()-touch[1]); if(wm!=null&&root!=null)wm.updateViewLayout(root,lp); return true; }
            return false;
        });
    }

    private void fillNews(List<String> n){ TextView[] v={root.findViewById(R.id.txtNews1),root.findViewById(R.id.txtNews2),root.findViewById(R.id.txtNews3)}; for(int i=0;i<3;i++)v[i].setText(i<n.size()?n.get(i):""); }

    private void startMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
        int rate=16000, min=AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if(min<=0) return;
        try {
            recorder=new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,min*2);
            recorder.startRecording();
            listening=true;
            final AudioRecord activeRecorder = recorder;
            final JarvisCoreView targetCore = core;
            final View targetRoot = root;
            targetCore.setMode(JarvisCoreView.Mode.LISTENING);
            micThread = new Thread(() -> {
                short[] buf=new short[min];
                while(listening && activeRecorder.getRecordingState()==AudioRecord.RECORDSTATE_RECORDING) {
                    int n=activeRecorder.read(buf,0,buf.length);
                    if(n<0) break;
                    if(n>0) {
                        double sum=0;
                        for(int i=0;i<n;i++){ double s=buf[i]/32768.0; sum+=s*s; }
                        double rms=Math.sqrt(sum/n);
                        float amp=(float)Math.min(1.0, rms*8.0);
                        mainHandler.post(() -> {
                            if(overlayActive && root==targetRoot && core==targetCore) {
                                targetCore.setAmplitude(amp);
                            }
                        });
                    }
                }
            },"JarvisMic");
            micThread.start();
        } catch(Exception ignored) {}
    }

    private Notification notification() {
        Intent i=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CH):new Notification.Builder(this);
        return b.setContentTitle("JARVIS HUD").setContentText("Yüzen panel aktif").setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setOngoing(true).build();
    }
    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationManager nm=getSystemService(NotificationManager.class); nm.createNotificationChannel(new NotificationChannel(CH,getString(R.string.notif_channel),NotificationManager.IMPORTANCE_LOW)); } }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density); }

    @Override public void onDestroy() {
        listening=false;
        overlayActive=false;
        mainHandler.removeCallbacksAndMessages(null);
        if (core != null) core.setMode(JarvisCoreView.Mode.IDLE);
        try { if(recorder!=null && recorder.getRecordingState()==AudioRecord.RECORDSTATE_RECORDING) recorder.stop(); } catch(Exception ignored) {}
        if (micThread != null) {
            try { micThread.join(); }
            catch (InterruptedException exception) { Thread.currentThread().interrupt(); }
            micThread = null;
        }
        try { if(recorder!=null) recorder.release(); } catch(Exception ignored) {}
        recorder=null;
        try { if(wm!=null && root!=null) wm.removeView(root); } catch(Exception ignored) {}
        root=null; core=null;
        super.onDestroy();
    }
}
